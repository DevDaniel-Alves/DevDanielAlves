/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package divi.sao;

/**
 *
 * @author 07556510140
 */
public class DiviSao {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int numerador, denominador, resto, quociente = 0;
        numerador = 45;
        denominador = 9;
        while(numerador > 0){
                numerador -= 9;
            quociente++;
        }
        System.out.println(quociente);
    }
    
}
