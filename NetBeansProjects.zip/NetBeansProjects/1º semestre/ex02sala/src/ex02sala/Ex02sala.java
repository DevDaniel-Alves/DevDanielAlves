/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ex02sala;

import java.util.Scanner;

public class Ex02sala {

    
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);    
        int x = 0, pos = 0, neg = 0; 
        for(int i = 0; i < 50; i++){
            x = input.nextInt();
            if(x > 0){
                pos += x;
            }else{
                neg++;
            }
            System.out.println("soma dos positivos"+pos);
            System.out.println("quant de negativos"+ neg);
        }
    }
}
