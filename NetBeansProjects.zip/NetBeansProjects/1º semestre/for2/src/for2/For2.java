/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package for2;

import java.util.Scanner;


public class For2 {
    
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        
        System.out.println("Informe a tabuada:");
        int tabuada = input.nextInt();
        
        for(int i = 1; i <= 10; i++){
            int r = i * tabuada;
            System.out.printf("%d x %d = %d\n", i, tabuada, r);
        }
    }
}
