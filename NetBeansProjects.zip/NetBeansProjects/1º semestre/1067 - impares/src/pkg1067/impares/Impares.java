package pkg1067.impares;
import java.util.Scanner;

public class Impares {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int cc = 0;
        while(cc < 4){
            System.out.println("Cambalhota");
            cc++;
        }
    }
}
