/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package incremento;

/**
 *
 * @author 07556510140
 */
public class Incremento {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        //Incremento posterior
        int c=0;
        c++;
        System.out.println(c);
        c++;
        System.out.println(c);
        c = c+1;
        System.out.println(c);
        //Incremento antecipado
        ++c;
        System.out.println(c);
        System.out.println(c++);
        System.out.println(c);
        System.out.println(++c);
        //Descemento Posterior
        
        c--;
        System.out.println(c);
        c+= 4; // c = c + 4;
        System.out.println(c);
        c-= 8;// c = c - 8;
        System.out.println(c);
        
        
    }
}
