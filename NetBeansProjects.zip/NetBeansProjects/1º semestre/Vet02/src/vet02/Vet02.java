/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package vet02;

public class Vet02 {

    public static void main(String[] args) {
        int vet1[] = new int[6];
        vet1[0] = 8;
        vet1[1] = 6;
        vet1[2] = 4;
        vet1[3] = 2;
        vet1[4] = 3;
        vet1[5] = 1;
        int vet2[] = new int[6];
        vet2[0]= 25;
        vet2[1]= 12;
        vet2[2]= 3;
        vet2[3]= 5;
        vet2[4]= 6;
        vet2[5]= 8;
        
    }
}
