/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package vetores2;

import java.util.Scanner;

public class Vetores2 {
    
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.println("Digite o tamanho do vetor: ");
        int tamanho = input.nextInt();
        int numeros[] = new int[tamanho];
        
        for(int i = 0; i < tamanho; i++){
            System.out.printf("Digite o número %d: ", i+1);
            numeros[i] = input.nextInt();
        }
        int soma = 0;
        for(int i = 0; i < tamanho; i++){
            soma += numeros[i];
        }
        System.out.println(soma);
    }
}