/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ex01;
import java.util.Scanner;
/**
 *
 * @author 07556510140
 */
public class Ex01 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int a, b, c, resultado, maior;
        a = input.nextInt();
        b = input.nextInt();
        c = input.nextInt();
        resultado = (a+b+Math.abs(a-b))/2;
        maior = (resultado+c+Math.abs(resultado-c))/2;
        System.out.println(maior + " eh o maior");
    }
}
