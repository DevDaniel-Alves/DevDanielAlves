package estrutura.de.condição;
import java.util.Scanner;

public class EstruturaDeCondição {
    
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.println("101 - Raiz quadrada");
        System.out.println("102 - A metade");
        System.out.println("103 - 10% do número");
        System.out.println("104 - O dobro");
        System.out.println("Digite um Codigo: ");
        int cod = input.nextInt();
        System.out.println("Digite um numero: ");
        int numero = input.nextInt();
        switch(cod){
            case 101:
                if(numero> 0){
                    System.out.println(Math.sqrt(numero));
                }else{
                    System.out.println("Não existe raiz de numero negativo");
                }
                break;
            case 102:
                System.out.println(numero/2);
                break;
            case 103:
                System.out.println(numero/10);
                break;
            case 104:
                System.out.println(numero*2);
                break;
            default:
                System.out.println("Invalido");
        }
    }
}
