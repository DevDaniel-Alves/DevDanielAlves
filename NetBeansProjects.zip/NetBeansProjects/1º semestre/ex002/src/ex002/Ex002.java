/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ex002;

import java.util.Scanner;

/**
 *
 * @author 07556510140
 */
public class Ex002 {
    
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int n1, n2;
        n1 = input.nextInt();
        n2 = input.nextInt();
        for(int i = n1;i<=n2;i++){
            System.out.println(i);
        }
    }
}
