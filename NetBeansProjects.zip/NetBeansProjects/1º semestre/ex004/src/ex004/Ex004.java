/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ex004;

import java.util.Scanner;

/**
 *
 * @author 07556510140
 */
public class Ex004 {
    
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int n1, n2, p, m;
        n1 = 0;
        n2 = 0;
        p = 0;
        m = 0;
        n1 = input.nextInt();

        for (int i = 0; i < n1; i++) {
            n2 = input.nextInt();
            if (n2 > m) {
                m = n2;
                p = i;
            }
        }
        System.out.println(m);
        System.out.println(p);
    }
}