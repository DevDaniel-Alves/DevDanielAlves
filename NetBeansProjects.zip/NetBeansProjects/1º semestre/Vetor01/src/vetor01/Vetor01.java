/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package vetor01;

import java.util.Scanner;

public class Vetor01 {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int n[] = {3, 2, 8, 7, 5, 4};
        for (int i = 0; i <= 5; i++) {
            System.out.println("Na posi��o " + i + " Temos o valor " + n[i]);;
        }
    }
}
