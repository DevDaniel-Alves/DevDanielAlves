/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package while2;

import java.util.Scanner;

/**
 *
 * @author danie
 */
public class While2 {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        String nome;
        System.out.println("Digite seu nome ou s para sair:");
        nome = input.nextLine();
        while (!nome.equals("s")){
            System.out.printf("Bem vindo %s\n", nome);
            System.out.println("Digite seu nome ou s para sair:");
            nome = input.nextLine();
        }
        System.out.println("Fim da execução!");
    }
    
}