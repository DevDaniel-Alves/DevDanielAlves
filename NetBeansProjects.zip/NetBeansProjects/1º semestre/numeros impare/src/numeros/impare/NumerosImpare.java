package numeros.impare;
import java.util.Scanner;

public class NumerosImpare {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int ler = input.nextInt();
        int cont = 0;
        while(cont < 6){
            if (ler % 2 ==1){
                System.out.println(ler);
                cont++;
            }
            ler++;
        }
    }
}
