/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ex02;
import java.util.Scanner;
/**
 *
 * @author 07556510140
 */
public class Ex02 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int a = input.nextInt();
        
        int notas100 = a/100;
        int res100 = a%100;
        
        int notas50 = res100/50;
        int res50 = notas50%50;
        
        int notas20 = res50/20;
        int res20 = a%20;
        
        System.out.println(notas100);
        System.out.println(notas50);
        System.out.println(notas20);
    }
    
}
