package matriz;

import java.util.Scanner;

public class Matriz {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        final int TAMANHO = 2;
        final int LINHA_NOME = 0;
        final int LINHA_FONE = 1;
        final int LINHA_ENDER = 2;
        String[][] dados = new String[3][TAMANHO];

        for (int i = 0; i < TAMANHO; i++) {
            System.out.println("Digite o nome: ");
            dados[LINHA_NOME][i] = input.nextLine();
            System.out.println("Digite o telefone: ");
            dados[LINHA_FONE][i] = input.nextLine();
            System.out.println("Digite o endere�o: ");
            dados[LINHA_ENDER][i] = input.nextLine();
        }
        for (int i = 0; i < TAMANHO; i++) {
            System.out.print("Nome: " + dados[LINHA_NOME][i] + " Telefone: " + dados[LINHA_FONE][i] + " Endereço " + dados[LINHA_ENDER][i]);
            System.out.println("");
        }
    }
}
