/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package calcularosimples;
import java.util.Scanner;
import java.util.Locale;
/**
 *
 * @author 07556510140
 */
public class Calcularosimples {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Locale.setDefault(Locale.GERMAN);
        Scanner input = new Scanner(System.in); 
        int num1, num2;
        num1 = input.nextInt();
        num2 = input.nextInt();
        int soma = num1+num2;
        int sub = ;
        int mult = ;
        System.out.println(soma);
    }
    
}
