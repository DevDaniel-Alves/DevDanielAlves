/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ex003;

import java.util.Scanner;

public class Ex003 {
    
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int n1, n2;
        n1 = input.nextInt();
        n2 = input.nextInt();
        for(int i = n1;i<=n2;i++){
            if((i%4)==0){
                System.out.println("PUM");
            }else{
                System.out.println(i);
            }
        }
    }
}