0
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package sequencia1a100;

/**
 *
 * @author 07556510140
 */
public class Sequencia1a100 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int sequencia = 1;
        
    }
    
}
