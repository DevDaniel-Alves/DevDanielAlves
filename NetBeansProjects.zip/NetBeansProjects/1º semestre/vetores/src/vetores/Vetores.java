package vetores;

import java.util.Scanner;

public class Vetores {

    public static void main(String[] args) {
        int num[] = new int[5];
        Scanner input = new Scanner(System.in);
        num[0] = input.nextInt();
        num[1] = input.nextInt();
        num[2] = input.nextInt();
        num[3] = input.nextInt();
        num[4] = input.nextInt();
        /*System.out.println(num[0]);
        System.out.println(num[1]);
        System.out.println(num[2]);
        System.out.println(num[3]);
        System.out.println(num[4]);*/
        for(int i = 0; i< 5;i++){
            System.out.println(num[i]);
        }
    }
}