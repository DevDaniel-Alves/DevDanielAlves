/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package soma.media.de.numero;

import java.util.Scanner;

public class SomaMediaDeNumero {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        double numero = 0;
        double soma = 0;
        int qtdenumero = 0; 
        
        while(numero != 9999){
        System.out.println("Digite um numero:");
        numero = input.nextDouble();
        qtdenumero++;
        System.out.println(qtdenumero);
        soma = soma + numero;
        }
        
        qtdenumero--;
        soma -= 9999;
        double media = soma/qtdenumero;
        System.out.printf("Soma: %.2f\nmedia: %.2f\n", soma, media);
    }
}
