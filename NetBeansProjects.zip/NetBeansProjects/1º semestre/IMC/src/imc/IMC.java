package imc;

import java.util.Scanner;

public class IMC {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int tamanho = 2;
        int opcao = 0;
        String nomes[] = new String[tamanho];
        double peso[] = new double[tamanho];
        double altura[] = new double[tamanho];

        while (opcao != 3) {
            System.out.println("---MENU---");
            System.out.println("1. Cadastrar Clientes");
            System.out.println("2. Listar Clientes");
            System.out.println("3. Sair");
            System.out.println("Escolha uma opção");
            opcao = input.nextInt();
            if (opcao == 1) {
                System.out.println("---Cadastro de cliente---");
                for (int i = 0; i < tamanho; i++) {
                    System.out.println("Nomes: ");
                    nomes[i] = input.next();
                    System.out.println("Pesos: ");
                    peso[i] = input.nextDouble();
                    System.out.println("Altura: ");
                    altura[i] = input.nextDouble();
                }
            } else if (opcao == 2) {
                double imc;
                System.out.println("---Listagem de Clientes");
                for (int i = 0; i < tamanho; i++) {
                    if (altura[i] != 0.0) {
                        imc = peso[i] / Math.pow(altura[i], 2.0);
                    } else {
                        imc = 0.0;
                    }
                    System.out.printf("%s \t %.2f \t Altura: %.2f\n", nomes[i], imc, altura[i]);
                    
                }
            }
        }
    }
}
