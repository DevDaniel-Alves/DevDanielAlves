/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package vetore;

import java.util.Scanner;

public class Vetore {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.println("Quantos numeros deseja armazenar: ");
        int tamanho = input.nextInt();
        int nomes[] = new int[tamanho];
        System.out.println("Digite os numeros");
        int soma = 0;
        int i = 0;
        while (i < tamanho) {
            nomes[i] = input.nextInt();
            soma = soma + nomes[i];
            i++;
        }
        System.out.println(soma);
    }
}
