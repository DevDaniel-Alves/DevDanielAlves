/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package numero.pkg1.a.pkg100;

import java.util.Scanner;

public class Numero1A100 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int num = 1;
        while(num <= 100){
            System.out.println(num);
            num++;
        }
    }
}
