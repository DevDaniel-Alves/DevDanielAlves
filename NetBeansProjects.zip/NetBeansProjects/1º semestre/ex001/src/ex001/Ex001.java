/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ex001;

/**
 *
 * @author 07556510140
 */
public class Ex001 {

    public static void main(String[] args) {
        int num = 1;
        while(num <= 100){
            System.out.println(num);
            num++;
        }
    }
}
