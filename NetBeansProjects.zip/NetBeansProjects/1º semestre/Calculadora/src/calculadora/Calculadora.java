/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package calculadora;
import java.util.Scanner;
public class Calculadora {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        double num1, num2, soma;
        char op;
        System.out.print("Digite o operador: ");
        op = input.next().charAt(0);
        System.out.print("Digite o primeiro valor: ");
        num1 = input.nextDouble();
        System.out.print("Digite o segundo valor: ");
        num2 = input.nextDouble();
        switch(op){
            case '*':
                System.out.println("A multiplicação é: "+ (num1*num2));
                break;
            case '/':
                System.out.println("A divisão é: "+ (num1/num2));
                break;
            case '-':
                System.out.println("A subtração é: "+ (num1-num2));
                break;
            case '+':
                System.out.println("A soma é: "+ (num1+num2));
                break;
            default:
                System.out.println("Valor invalido");
        }
    }
}
