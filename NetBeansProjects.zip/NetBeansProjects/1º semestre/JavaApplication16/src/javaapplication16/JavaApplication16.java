/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package javaapplication16;

import java.util.Scanner;

public class JavaApplication16 {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        String mes[] = new String[12];
        mes[0] = input.next();
        mes[1] = input.next();
        mes[2] = input.next();
        mes[3] = input.next();
        mes[4] = input.next();
        mes[5] = input.next();
        mes[6] = input.next();
        mes[7] = input.next();
        mes[8] = input.next();
        mes[9] = input.next();
        mes[10] = input.next();
        mes[11] = input.next();
        for(int i = 0; i < 12; i++){
            System.out.println(mes[i] + " Est� na posi��o " + i);
        }
    }

}
