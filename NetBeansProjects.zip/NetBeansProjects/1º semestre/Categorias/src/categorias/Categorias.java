/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package categorias;
import java.util.Scanner;

public class Categorias {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int idade;
        String nome;
        System.out.println("Nome do atleta: ");
        nome = input.nextLine();
        System.out.println("Idade do atleta: ");
        idade = input.nextInt();
        switch(idade){
            case 5: case 6: case 7: case 8: case 9: case 10:
                System.out.println("Infantil");
                break;
            case 11: case 12: case 13: case 14: case 15:
                System.out.println("Juvenil");
                break;
            case 16: case 17: case 18: case 19: case 20:
                System.out.println("Junior");
                break;
            case 21: case 22: case 23: case 24: case 25:
                System.out.println("Profissional");
                break;
            default:
                System.out.println("Idade invalida");
        }
    }
}
