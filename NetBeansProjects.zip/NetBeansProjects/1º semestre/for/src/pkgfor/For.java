/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package pkgfor;

import java.util.Scanner;

/**
 *
 * @author 07556510140
 */
public class For {
    
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        for (int i = 1; i <= 10; i++){
            int r = i * 2;
            System.out.printf("%d x 2 = %d\n", i, r);
        }
    }
}
