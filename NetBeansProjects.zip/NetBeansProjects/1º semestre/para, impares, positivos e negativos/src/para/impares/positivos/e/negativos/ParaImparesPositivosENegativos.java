/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package para.impares.positivos.e.negativos;

import java.util.Scanner;

public class ParaImparesPositivosENegativos {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int n, par = 0, impar = 0, pos = 0, neg = 0;
        for (int i = 0; i < 5; i++) {
            n = input.nextInt();
            if (n % 2 == 0) {
                par++;
            } else {
                impar++;
            }
            if (n > 0) {
                pos++;
            }
            if (n < 0) {
                neg++;
            }
        }
        System.out.println(par + "valor(es) par(es)");
        System.out.println(impar + "valor(es) impar(es)");
        System.out.println(pos + "valor(es) positivo(s)");
        System.out.println(neg + "valor(es) negativo(s)");
    }

}
