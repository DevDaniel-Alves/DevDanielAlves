/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package teste.pkgswitch.pkg2;
import java.util.Scanner;

public class TesteSwitch2 {
    
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        char sexo;
        System.out.println("Digite o sexo(M/F)");
        sexo = input.next().charAt(0);
        switch(sexo){
            case 'M':
            case 'm':
                System.out.println("Masculino");
                break;
            case 'F':
            case 'f':
                System.out.println("Feminino");
                break;
            default:
                System.out.println("Opção Invalida");
        }
    }
}
