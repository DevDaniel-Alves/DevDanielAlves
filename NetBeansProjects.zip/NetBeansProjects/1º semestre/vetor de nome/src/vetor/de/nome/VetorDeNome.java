package vetor.de.nome;

import java.util.Scanner;
public class VetorDeNome {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.println("Quantos nomes deseja armazenar: ");
        int tamanho = input.nextInt();
        String nomes[] = new String[tamanho];
        System.out.println("Digite os nomes");
        int i = 0;
        while(i < tamanho){
            nomes[i] = input.next();
            i++;
        }
        i = 0;
        while(i < tamanho){
            System.out.printf("%d - %s\n",i+1, nomes[i]);
            i++;
        }
    }
}