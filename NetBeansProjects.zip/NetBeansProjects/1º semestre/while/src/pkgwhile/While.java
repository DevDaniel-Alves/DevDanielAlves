/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package pkgwhile;

import java.util.Scanner;


public class While {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.println("Qual a tabuada: ");
        int tabuada = input.nextInt();
        int a = 1;
        while(a <= 10){
            int r = a * tabuada;
            System.out.printf("%d x %d = %d\n", a, tabuada, r);
            a++;
        }
    }
    
}
