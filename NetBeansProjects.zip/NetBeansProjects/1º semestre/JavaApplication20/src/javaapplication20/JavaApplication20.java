
package javaapplication20;

public class JavaApplication20 {
    
    public static void main(String[] args) {
        
    }
}